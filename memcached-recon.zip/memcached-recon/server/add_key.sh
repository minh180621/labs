#!/bin/bash

echo -e "set flag 0 0 10\r\nflag_value\r\n" | /bin/nc -q 1 127.0.0.1 11211
echo -e "set first_name 0 0 4\r\nJohn\r\n" | /bin/nc -q 1 127.0.0.1 11211
