from pymemcache.client import base

client = base.Client(('127.0.0.1', 11211))

keys = {
    'flag': 'flag_value',
    'first_name': 'John',
    'phone': '0948995325',
    'email': 'minh@gmail.com',
    'lunch': 'instant',
    'gate': 'zero',
}

for key, value in keys.items():
    client.set(key, value)

for key in keys:
    value = client.get(key)
    print(f"{key}: {value.decode('utf-8')}")

