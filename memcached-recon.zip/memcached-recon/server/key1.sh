echo -e "set flag 0 0 4\r\ntrue\r\n" | nc localhost 11211
